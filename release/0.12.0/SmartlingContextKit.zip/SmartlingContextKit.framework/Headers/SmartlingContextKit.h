//
//  SmartlingContextKit.h
//  SmartlingContextKit
//
//  Created by Scott Rossillo on 11/4/14.
//  Copyright (c) 2014 Smartling, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SmartlingContextKit.
FOUNDATION_EXPORT double SmartlingContextKitVersionNumber;

//! Project version string for SmartlingContextKit.
FOUNDATION_EXPORT const unsigned char SmartlingContextKitVersionString[];
